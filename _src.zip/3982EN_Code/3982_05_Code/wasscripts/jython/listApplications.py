#This Jython code will list all the applications installed on your WebSphere server.
print AdminApp.list()
