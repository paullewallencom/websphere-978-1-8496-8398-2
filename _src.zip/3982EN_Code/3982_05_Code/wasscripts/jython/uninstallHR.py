#Uninstall the application
appName="HRListerEAR"
AdminApp.uninstall(appName);
#save
AdminConfig.save();