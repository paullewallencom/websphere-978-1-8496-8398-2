#Get cell name
cellName = AdminControl.getCell()
print "Cell name = " + cellName